
Dennne innlevering er laget av: **Mark Tzvetoslavov**

# **Oppgave 2 - Forståelse og forklaring av database design**

Databasen **ga-bibliotek** er designet for å støtte et biblioteksystem hvor brukere kan låne bøker, og biblioteket
kan holde oversikt over bøker, eksemplarer, låntakere, og utlånstransaksjoner. Databasen består av flere
tabeller:


1. `bok`
2. `eksemplar`
3. `låner`
4. `utlån`


## Oppgavebeskrivelse 📚

### a) Tabell: `bok` 📖

Denne tabellen inneholder informasjon om alle bøker som er en del av biblioteket. `ISBN` bruker primærnøkkel fordi den er unik for hver bok i biblioteket. `CHECK`-constraints beskytter mot ugyldige verdier som for eksempel negative sidetall.



| Kolonnenavn | Datatype     | Constraint                                       | Beskrivelse                  |
| ----------- | ------------ | ------------------------------------------------ | ---------------------------- |
| ISBN        | VARCHAR(17)  | PRIMARY KEY                                      | Unik identifikator for boka. |
| Tittel      | VARCHAR(255) | NOT NULL                                         | Bokas tittel.                |
| Forfatter   | VARCHAR(255) | NOT NULL                                         | Navn på forfatter.           |
| Forlag      | VARCHAR(255) | NOT NULL                                         | Navn på forlaget.            |
| UtgittÅr    | INT          | NOT NULL, CHECK | Året boka ble utgitt.          |
| AntallSider | INT          | NOT NULL, CHECK (AntallSider > 0)                | Antall sider i boka.         |


### b) Tabell: `låner` 👤

Denne tabellen inneholder alt informasjon om alle personer som kan låne bøker fra biblioteket vårt. 
Her bruker vi en **primærnøkkel** (`LNr`) som "auto-inkrementerer" for hver ny låner. Dette er enklere enn å bruke navn som nøkkel. Alle felt er NOT NULL slik at man ikke kan registrere ufullstendige lånerdata.

| Kolonnenavn | Datatype     | Constraint                  | Beskrivelse                        |
| ----------- | ------------ | --------------------------- | ---------------------------------- |
| LNr         | INT UNSIGNED | PRIMARY KEY, AUTO_INCREMENT | Unik låner-ID generert automatisk. |
| Fornavn     | VARCHAR(100) | NOT NULL                    | Lånerens fornavn.                  |
| Etternavn   | VARCHAR(100) | NOT NULL                    | Lånerens etternavn.                |
| Adresse     | VARCHAR(255) | NOT NULL                    | Lånerens adresse.                  |


### c) Tabell: `eksemplar` 📦
Denne tabellen vil da vise alle de fysiske kopier eller eksemplarer av en viss bok. Her har jeg gjort til en kombinasjon av `ISBN` og `EksNr`. Denne kombinasjon gjør hvert eksemplar unikt. Dersom en bok blir slettet fra `bok`-tabellen vår bir alle **tilhørende** eksemplarer slettet automatisk (cascade). Jeg har kommentert det som handlinger litt lengre ned ...


**Primærnøkkel:** *(ISBN, EksNr)*
**Fremmednøkkel:** *(ISBN)* → `bok(ISBN)`
**Handlinger:** `ON DELETE CASCADE ON UPDATE CASCADE`



| Kolonnenavn | Datatype     | Constraint                        | Beskrivelse                              |
| ----------- | ------------ | --------------------------------- | ---------------------------------------- |
| ISBN        | VARCHAR(17)  | FOREIGN KEY → `bok(ISBN)`         | Referanse til boka eksemplaret tilhører. |
| EksNr       | INT UNSIGNED | PRIMARY KEY (del av kompositt PK) | Nummer på eksemplaret.                   |




### d) Tabell: `utlån` 🤝
Denne tabellen registrerer alle utlån i biblioteket.  Her vil  **`UtlånsNr`** auto-inkrementeres for hver ny registrering som gjøres på biblioteket vårt. Kolonnen med navn **Levert** har en **CHECK-constraint** som tillater kun verdiene 0 eller 1. Her vil fremmednøklene sikre at lånet bare kan registreres hvis boken, eksemplaret og låneren eksisterer.


| Kolonnenavn | Datatype     | Constraint                             | Beskrivelse                    |
| ----------- | ------------ | -------------------------------------- | ------------------------------ |
| UtlånsNr    | INT UNSIGNED | PRIMARY KEY, AUTO_INCREMENT            | Unik ID for utlånet.           |
| LNr         | INT UNSIGNED | FOREIGN KEY → `låner(LNr)`             | Lånerens ID.                   |
| ISBN        | VARCHAR(17)  | FOREIGN KEY → `bok(ISBN)`              | Referanse til boka som lånes.  |
| EksNr       | INT UNSIGNED | FOREIGN KEY → `eksemplar(ISBN, EksNr)` | Hvilket eksemplar som er lånt. |
| Utlånsdato  | DATE         | NOT NULL                               | Dato for utlån.                |
| Levert      | TINYINT(1)   | NOT NULL, CHECK (Levert IN (0,1))      | 0 = ikke levert, 1 = levert.   |



## **Primærnøkler og Fremmednøkler** 🔑
**Hvordan henger primærnøkler og fremmednøkler sammen:**

* `bok` kobles direkte til `eksemplar` via ISBN → dette betyr at en bok kan ha mange eksemplarer.
* `låner` kobles direkte til `utlån` via LNr → dette betyr at en låner kan ha flere utlån på sitt navn. 
* `utlån` kobles direkte til både `bok` og `eksemplar`. Dette viser oss hvilket eksemplar som er lånt ut.

**Referanseintegritet:**
Her er en liten forklaring på hvordan og hvorfor disse koblingene sikrer en referanse integritet:

* Man kan ikke registrere et eksemplar av en bok som desverre ikke finnes.
* Man kan ikke registrere et utlån til en låner som desverre ikke finnes.
* Man kan ikke slette bøker som har registrerte et utlån på seg ---> vi bruker derfor **RESTRICT**.
*   Hvis det er noe endringer som gjøres i nøkkelverdiene, oppdateres disse automatisk (CASCADE).

| Tabell      | Primærnøkkel  | Fremmednøkler                                                                        |
| ----------- | ------------- | ------------------------------------------------------------------------------------ |
| `bok`       | ISBN          | –                                                                                    |
| `låner`     | LNr           | –                                                                                    |
| `eksemplar` | (ISBN, EksNr) | ISBN → `bok(ISBN)`                                                                   |
| `utlån`     | UtlånsNr      | LNr → `låner(LNr)`<br>ISBN → `bok(ISBN)`<br>(ISBN, EksNr) → `eksemplar(ISBN, EksNr)` |


## **Constraints brukt i oppgaven**
Følgende constraints er regler som er brukt i oppgaven. Disse "regler" hindrer for feilregistreringer og sørger for at data henger sammen. Her er en liste over de som er brukt over hele oppgaven:



| Constraint-type                  | Eksempler i databasen                                          | Hvorfor de er viktige                                   |
| -------------------------------- | -------------------------------------------------------------- | ------------------------------------------------------- |
| **NOT NULL**                     | Fornavn, Etternavn, Adresse, Tittel, Utlånsdato                | Sikrer at viktige data alltid er fylt ut.               |
| **PRIMARY KEY**                  | ISBN, (ISBN, EksNr), LNr, UtlånsNr                             | Gir hver rad en unik identifikator.                     |
| **FOREIGN KEY**                  | LNr, ISBN, (ISBN, EksNr) i `utlån`                             | Sørger for at relasjonene mellom tabellene er gyldige.  |
| **CHECK**                        | Levert IN (0,1), AntallSider > 0, UtgittÅr mellom 1400 og 2100 | Forhindrer ugyldige eller urealistiske data.            |
| **AUTO_INCREMENT**               | LNr, UtlånsNr                                                  | Gir unike verdier automatisk uten manuell registrering. |
| **ON DELETE CASCADE / RESTRICT** | Mellom `bok`, `eksemplar` og `utlån`                           | Hindrer foreldreløse rader og bevarer historikk.        |
