DROP DATABASE IF EXISTS ga_bibliotek;
CREATE DATABASE IF NOT EXISTS ga_bibliotek;
ALTER DATABASE ga_bibliotek CHARACTER;
USE ga_bibliotek;

DROP TABLE IF EXISTS `utlån`;
DROP TABLE IF EXISTS `eksemplar`;
DROP TABLE IF EXISTS `låner`;
DROP TABLE IF EXISTS `bok`;

-- bok
CREATE TABLE `bok` (
  `ISBN`        VARCHAR(17)  NOT NULL,
  `Tittel`      VARCHAR(255) NOT NULL,
  `Forfatter`   VARCHAR(255) NOT NULL,
  `Forlag`      VARCHAR(255) NOT NULL,
  `UtgittÅr`    INT          NOT NULL CHECK (`UtgittÅr` BETWEEN 1400 AND YEAR(CURDATE())),
  `AntallSider` INT          NOT NULL CHECK (`AntallSider` > 0),
  PRIMARY KEY (`ISBN`),
  INDEX (`Forfatter`),
  INDEX (`Tittel`)
);

-- låner
CREATE TABLE `låner` (
  `LNr`       INT NOT NULL AUTO_INCREMENT,
  `Fornavn`   VARCHAR(100) NOT NULL,
  `Etternavn` VARCHAR(100) NOT NULL,
  `Adresse`   VARCHAR(255) NOT NULL,
  PRIMARY KEY (`LNr`),
  INDEX (`Etternavn`)
);

-- eksemplar
CREATE TABLE `eksemplar` (
  `ISBN`  VARCHAR(13) NOT NULL,
  `EksNr` INT         NOT NULL,
  PRIMARY KEY (`ISBN`,`EksNr`),
  CONSTRAINT `fk_eksemplar_bok`
    FOREIGN KEY (`ISBN`) REFERENCES `bok`(`ISBN`)
    ON UPDATE CASCADE ON DELETE RESTRICT
);

-- utlån
CREATE TABLE `utlån` (
  `UtlånsNr`   INT NOT NULL AUTO_INCREMENT,
  `LNr`        INT NOT NULL,
  `ISBN`       VARCHAR(13) NOT NULL,
  `EksNr`      INT NOT NULL,
  `Utlånsdato` DATE NOT NULL,
  `Levert`     TINYINT(1) NOT NULL DEFAULT 0 CHECK (`Levert` IN (0,1)),
  PRIMARY KEY (`UtlånsNr`),
  KEY `idx_utlaan_lnrisbn` (`LNr`, `ISBN`),
  CONSTRAINT `fk_utlaan_laaner`
    FOREIGN KEY (`LNr`) REFERENCES `låner`(`LNr`)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT `fk_utlaan_eksemplar`
    FOREIGN KEY (`ISBN`,`EksNr`) REFERENCES `eksemplar`(`ISBN`,`EksNr`)
    ON UPDATE CASCADE ON DELETE RESTRICT
);


INSERT INTO `bok` (`ISBN`,`Tittel`,`Forfatter`,`Forlag`,`UtgittÅr`,`AntallSider`) VALUES
('9780140449136','The Art of War','Sun Tzu','Penguin Classics',2003,273),
('9780143127741','The 48 Laws of Power','Robert Greene','Penguin Books',2000,452),
('9780143111702','The 33 Strategies of War','Robert Greene','Penguin Books',2006,496),
('9780142001745','The Prince','Niccolò Machiavelli','Penguin Books',2003,144),
('9780399592522','Atomic Habits','James Clear','Avery',2018,320),
('9780349413686','Think and Grow Rich','Napoleon Hill','Vermilion',2016,320),
('9780671027032','Rich Dad Poor Dad','Robert T. Kiyosaki','Warner Books',1997,207),
('9780735211292','The Subtle Art of Not Giving a F*ck','Mark Manson','Harper',2016,224),
('9780062312686','The Power of Habit','Charles Duhigg','Random House',2012,371),
('9781847941831','Thinking, Fast and Slow','Daniel Kahneman','Penguin Books',2012,499),
('9781476759803','Start with Why','Simon Sinek','Portfolio',2011,256),
('9781982137274','Can’t Hurt Me','David Goggins','Lioncrest Publishing',2018,364),
('9781250277800','The Psychology of Money','Morgan Housel','Harriman House',2020,252),
('9781455586691','You Are a Badass','Jen Sincero','Running Press',2013,256),
('9780091906818','The 7 Habits of Highly Effective People','Stephen R. Covey','Simon & Schuster',1989,381),
('9780345472328','The Millionaire Next Door','Thomas J. Stanley & William D. Danko','Longstreet Press',1996,272),
('9780593139134','Ego is the Enemy','Ryan Holiday','Portfolio',2016,226),
('9781781251492','Deep Work','Cal Newport','Piatkus',2016,304),
('9780735224087','Principles: Life and Work','Ray Dalio','Simon & Schuster',2017,592),
('9780679720201','Man’s Search for Meaning','Viktor E. Frankl','Beacon Press',2006,200);

-- ===========================================
-- Lånere (10 stk)
-- ===========================================

INSERT INTO `låner` (`Fornavn`,`Etternavn`,`Adresse`) VALUES
('Anna','Berg','Parkveien 12, 0253 Oslo'),
('Ola','Nordmann','Storgata 5, 0184 Oslo'),
('Kari','Hansen','Markveien 88, 0554 Oslo'),
('Per','Johansen','Sørkedalsveien 21, 0369 Oslo'),
('Sofie','Lie','Rosenkrantzgate 11, 0160 Oslo'),
('Jonas','Lund','Bergensgata 3, 0468 Oslo'),
('Herman','Skaug','Dronningens gate 7, 0152 Oslo'),
('Nora','Viken','Løkkeveien 24, 4008 Stavanger'),
('Mina','Sæther','Kongens gate 5, 7013 Trondheim'),
('Ali','Aziz','Stakkevollvegen 20, 9010 Tromsø');

-- ===========================================
-- Eksemplarer (1–3 per tittel)
-- (bruk samme ISBN som i bok-lista di)
-- ===========================================

INSERT INTO `eksemplar` (`ISBN`,`EksNr`) VALUES
('9780140449136',1),('9780140449136',2),                                -- The Art of War
('9780143127741',1),('9780143127741',2),('9780143127741',3),            -- The 48 Laws of Power
('9780143111702',1),('9780143111702',2),                                 -- The 33 Strategies of War
('9780142001745',1),('9780142001745',2),                                 -- The Prince
('9780399592522',1),('9780399592522',2),('9780399592522',3),             -- Atomic Habits
('9780349413686',1),('9780349413686',2),                                 -- Think and Grow Rich
('9780671027032',1),('9780671027032',2),                                 -- Rich Dad Poor Dad
('9780735211292',1),('9780735211292',2),                                 -- The Subtle Art...
('9780062312686',1),('9780062312686',2),                                 -- The Power of Habit
('9781847941831',1),('9781847941831',2),                                 -- Thinking, Fast and Slow
('9781476759803',1),                                                     -- Start with Why
('9781982137274',1),                                                     -- Can’t Hurt Me
('9781250277800',1),('9781250277800',2),                                 -- The Psychology of Money
('9781455586691',1),                                                     -- You Are a Badass
('9780091906818',1),('9780091906818',2),                                 -- 7 Habits
('9780345472328',1),                                                     -- Millionaire Next Door
('9780593139134',1),                                                     -- Ego is the Enemy
('9781781251492',1),('9781781251492',2),                                 -- Deep Work
('9780735224087',1),                                                     -- Principles
('9780679720201',1);                                                     -- Man’s Search for Meaning

-- ===========================================
-- Utlån (noen levert (1), noen ikke (0))
-- Forutsetter AUTO_INCREMENT på UtlånsNr
-- ===========================================

INSERT INTO `utlån` (`LNr`,`ISBN`,`EksNr`,`Utlånsdato`,`Levert`) VALUES
(1,'9780399592522',2,'2025-09-15',1),      -- Atomic Habits
(1,'9781781251492',1,'2025-10-12',0),      -- Deep Work
(2,'9780143127741',1,'2025-08-20',1),      -- 48 Laws
(2,'9780062312686',2,'2025-10-01',0),      -- Power of Habit
(3,'9781847941831',1,'2025-07-05',1),      -- Thinking, Fast and Slow
(3,'9781250277800',1,'2025-09-28',0),      -- Psychology of Money
(4,'9780142001745',2,'2025-06-18',1),      -- The Prince
(5,'9780091906818',1,'2025-07-22',1),      -- 7 Habits
(5,'9781476759803',1,'2025-10-03',0),      -- Start with Why
(6,'9780671027032',1,'2025-09-10',1),      -- Rich Dad Poor Dad
(7,'9780143111702',2,'2025-09-30',0),      -- 33 Strategies
(8,'9780735224087',1,'2025-08-02',1),      -- Principles
(9,'9780140449136',1,'2025-09-14',1),      -- Art of War
(10,'9780345472328',1,'2025-10-06',0),     -- Millionaire Next Door
(4,'9780593139134',1,'2025-09-01',1),      -- Ego is the Enemy
(6,'9780735211292',2,'2025-10-10',0);      -- Subtle Art

