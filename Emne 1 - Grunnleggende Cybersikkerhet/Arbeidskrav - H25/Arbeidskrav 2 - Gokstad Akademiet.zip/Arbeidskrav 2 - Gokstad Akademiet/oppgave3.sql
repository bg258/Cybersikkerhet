-- 1. Skriv en SQL spørring som henter alle bøker publisert etter år 2000. --
SELECT * 
FROM `bok`
WHERE `UtgittÅr` > 2000;

-- 2. Skriv en SQL spørring som henter forfatternavn og tittel på alle bøker sortert alfabetisk etter forfatter.
SELECT `Forfatter`, `Tittel`
FROM `bok`
ORDER BY `Forfatter` ASC, `Tittel` ASC;

-- 3. Skriv en SQL spørring som henter alle bøker med mer enn 300 sider
SELECT *
FROM `bok`
WHERE `AntallSider` > 300;

-- 4. Skriv en SQL som legger til en ny bok i tabellen 'bok'. (Bok finner du selv)

INSERT INTO `bok` (`ISBN`,`Tittel`,`Forfatter`,`Forlag`,`UtgittÅr`,`AntallSider`)
VALUES ('9780061128888','The Bible','Jesus','The Bible company',1988, 888);

-- 5. Skriv en SQL som legger til en ny låner i tabellen 'låner'.
INSERT INTO `låner` (`Fornavn`,`Etternavn`,`Adresse`)
VALUES ('Mark','Tzvetoslavov','Jesus Kristus Gate 88, 0111 Oslo');

-- 6. Skriv en SQL som oppdaterer adresse for en spesifikk låner
UPDATE `låner`
SET `Adresse` = 'Ny adresse 123, 0001 Oslo'
WHERE `LNr` = 2;

-- 7. Skriv en SQL som henter alle utlån sammen med lånerens navn og bokens tittel
SELECT u.`UtlånsNr`, u.`Utlånsdato`, u.`Levert`,
       l.`Fornavn`, l.`Etternavn`,
       b.`Tittel`
FROM `utlån` u
JOIN `låner` l ON l.`LNr` = u.`LNr`
JOIN `bok`   b ON b.`ISBN` = u.`ISBN`
ORDER BY u.`Utlånsdato` DESC, u.`UtlånsNr` DESC;

-- 8. Skriv en SQL som henter alle bøker og antall eksemplarer for hver bok.
SELECT b.`ISBN`, b.`Tittel`, COUNT(e.`EksNr`) AS AntallEksemplarer
FROM `bok` b
LEFT JOIN `eksemplar` e ON e.`ISBN` = b.`ISBN`
GROUP BY b.`ISBN`, b.`Tittel`
ORDER BY b.`Tittel`;

-- 9. Skriv en SQL som henter antall utlån per låner.
SELECT l.`LNr`, l.`Fornavn`, l.`Etternavn`, COUNT(u.`UtlånsNr`) AS AntallUtlån
FROM `låner` l
LEFT JOIN `utlån` u ON u.`LNr` = l.`LNr`
GROUP BY l.`LNr`, l.`Fornavn`, l.`Etternavn`
ORDER BY AntallUtlån DESC, l.`Etternavn`, l.`Fornavn`;

-- 10. Skriv en SQL som henter antall utlån per bok
SELECT b.`ISBN`, b.`Tittel`, COUNT(u.`UtlånsNr`) AS AntallUtlån
FROM `bok` b
LEFT JOIN `utlån` u ON u.`ISBN` = b.`ISBN`
GROUP BY b.`ISBN`, b.`Tittel`
ORDER BY AntallUtlån DESC, b.`Tittel`;

-- 11. Skriv en SQL som henter alle bøker som ikke har blitt lånt ut.
SELECT b.`ISBN`, b.`Tittel`
FROM `bok` b
LEFT JOIN `utlån` u ON u.`ISBN` = b.`ISBN`
WHERE u.`UtlånsNr` IS NULL
ORDER BY b.`Tittel`;

-- 12. Skriv en SQL som henter forfatter og antall utlånte bøker per forfatter.
SELECT b.`Forfatter`, COUNT(u.`UtlånsNr`) AS AntallUtlån
FROM `bok` b
LEFT JOIN `utlån` u ON u.`ISBN` = b.`ISBN`
GROUP BY b.`Forfatter`
ORDER BY AntallUtlån DESC, b.`Forfatter`;