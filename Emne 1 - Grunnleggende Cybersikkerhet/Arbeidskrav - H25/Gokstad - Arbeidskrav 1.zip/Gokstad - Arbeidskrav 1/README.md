# Arbeidskrav 1– Python (README)

Denne README-en er laget for å beskrive hele innleveringen nub og hvordan jeg kjører/opptester **alle oppgavene**.
Mappestrukturen er lagt opp slik at hver deloppgave ligger i sitt eget mappe (1–4), mens oppgave 5 ligger utenfor disse og heter `filanalyse`.


## Mappestruktur

```
.
├── Oppgave 1/
│   └── Oppgave1_1.py        # Oppg. 1.1–1.5
│   └── Oppgave1_2.py        # Oppg. 1.1–1.5
│   └── Oppgave1_3.py        # Oppg. 1.1–1.5
│   └── Oppgave1_4.py        # Oppg. 1.1–1.5
│   └── Oppgave1_5.py        # Oppg. 1.1–1.5
├── Oppgave 2/
│   └── Oppgave2_1.py        
│   └── Oppgave2_2.py   
│   └── Oppgave2_2.py   
│   └── Oppgave2_4.py   
│   └── Oppgave2_5.py      
│   └── Oppgave2_6.py
├── Oppgave 3/
│   └── Oppgave3_1.py       
│   └── Oppgave3_2.py  
│   └── Oppgave3_3.py      
│   └── Oppgave3_4.py  
├── Oppgave 4/
│   └── Oppgave4_1.py        
│   └── Oppgave4_2.py        
├── Filanalyse.py
│── bokutlån.csv
└── Arbeidskrav1.pdf
```

## Kjøring per oppgave

### Oppgave 1 – Grunnprogrammering (1.1–1.5)
Gå inn i mappen og kjør fila:
```bash
cd "Oppgave 1"
python oppgave1_1.py
# eller: python3 oppgave1_1.py
```

osv...


### Oppgave 5 – Filanalyse (5.1–5.5)
```bash
python Filanalyse.py --fil bokutlån.csv
# eller: python filanalyse.py --fil bokutlån.csv
```