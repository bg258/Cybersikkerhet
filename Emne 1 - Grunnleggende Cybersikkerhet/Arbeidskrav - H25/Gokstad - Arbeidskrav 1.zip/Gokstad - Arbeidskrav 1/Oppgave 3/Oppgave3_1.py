# Oppgave 3.1
# Lag en funksjon som tar inn en streng og sjekker om det er en gyldig
# IPv4-adresse. En gyldig IPv4-adresse har fire deler atskilt med punktum
#(_), der hver del er et heltall mellom 0 og 255. Funksjonen skal returnere
# True hvis det er en gyldig adresse, og False ellers. Eksempel:

"""
Input: "192.168.0.1" → Output: True
Input: "256.100.50.0" → Output: False
"""

def sjekke_om_input_er_gyldig_ipv4(adresse_ipv4):
    deler = adresse_ipv4.split(".")
    if len(deler) != 4:
        return False
    for delstr in deler:
        if not delstr.isdigit():
            return False
        tall = int(delstr)
        if tall < 0 or tall > 255:
            return False
    return True

if __name__ == "__main__":
    adr = input("Skriv inn en IP-adresse: ")
    if sjekke_om_input_er_gyldig_ipv4(adr):
        print("Gyldig IPv4-adresse")
    else:
        print("Ugyldig IPv4-adresse")
