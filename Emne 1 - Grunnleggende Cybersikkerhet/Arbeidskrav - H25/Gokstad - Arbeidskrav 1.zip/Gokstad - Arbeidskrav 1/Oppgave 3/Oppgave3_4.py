# Oppgave 3.4
# Lag en funksjon som tar en annen funksjon som parameter, noen argumenter
# og et forventet resultat, og som returnerer sant hvis det faktiske resultatet
# stemmer overens med det forventede resultatet, ellers usant.

from Oppgave3_3 import rgb_to_hexadecimal

def assert_function(func, args, expected):
    try:
        return func(*args) == expected
    except Exception:
        return False

if __name__ == "__main__":
    print(assert_function(rgb_to_hexadecimal, (205, 92, 92), "#CD5C5C"))

