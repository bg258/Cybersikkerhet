"""
Oppgave 3.3
I dataprogrammering brukes fargekoder ofte for˚a representere farger i brukergrensesnitt
og grafikk. To vanlige m˚ater ˚a representere farger p˚a er:

1. Hex-kode: En fargekode som starter med # og best˚ar av seks tegn
som representerer de røde, grønne og bl˚a komponentene i fargen (for
eksempel #CD5C5C). Hver komponent har to tegn (heksadesimalt),
hvor:
    • CD representerer rødt (r),
    • 5C representerer rødt (g), og
    • 5C representerer bl˚att (b),

2. RGB-kode: En fargekode representert som tre heltall, ´en for hver
fargekomponent (rød, grønn, bl˚a). For eksempel: rgb(205, 92, 92).
Lag en funksjon rgb to hex som tar inn tre heltall (for eksempel red=205,
green=92, blue=92) og returnerer tilsvarende Hex-kode som en streng (for
eksempel "#CD5C5C"). Legg ogs˚a til passende feilmelding om red, blue eller
green parametere har ugyldig verdi.
"""

def rgb_to_hexadecimal(r, g, b):
    if not (0 <= r <= 255 and 0 <= g <= 255 and 0 <= b <= 255):
        return "dette her er et ugyldig verdi, den må være mellom 0 og 255"
    return "#{:02X}{:02X}{:02X}".format(r, g, b)

if __name__ == "__main__":
    try:
        r = int(input("Skriv inn verdi for rød (0-255): "))
        g = int(input("Skriv inn verdi for grønn (0-255): "))
        b = int(input("Skriv inn verdi for blå (0-255): "))
        print("Hex-kode:", rgb_to_hexadecimal(r, g, b))
    except ValueError:
        print("Du må skrive inn heltall")
