from datetime import date

# Oppgave 3.2
# Lag en funksjon som tar inn to datoer som strenger p˚a formatet “dd/mm/yyyy”
# og returnerer antall dager mellom dem. Hvis den første datoen er senere enn
# den andre, skal funksjonen fortsatt returnere antall dager (positivt tall).

"""
Input: "21/11/2024", "01/01/2024" → Output: 325 dager
"""

from datetime import date

def totalt_antall_dager_mellom_dem(d1, d2):
    d, m, y = d1.split("/")
    dato1 = date(int(y), int(m), int(d))
    d, m, y = d2.split("/")
    dato2 = date(int(y), int(m), int(d))
    return abs((dato2 - dato1).days)

if __name__ == "__main__":
    d1 = input("Skriv inn første dato (dd/mm/yyyy): ")
    d2 = input("Skriv inn andre dato (dd/mm/yyyy): ")
    print("Antall dager mellom datoene:", totalt_antall_dager_mellom_dem(d1, d2))
