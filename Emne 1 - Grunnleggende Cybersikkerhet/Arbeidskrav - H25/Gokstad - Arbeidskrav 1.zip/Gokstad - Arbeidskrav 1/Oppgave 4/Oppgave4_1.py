"""
Oppgave 4.1
Lag en funksjon som oppretter en mappe kalt Files og genererer 30 tilfeldige
filer med følgende filtyper i denne mappen: .txt, .csv, og .log. Hver fil
skal ha:
• Et tilfeldig navn med mellom 5 og 10 tegn.
• En tilfeldig filtype valgt fra de tre typene.
• Innhold i disse filen er ikke viktig—lag gjerne disse filene uten innhold
Files
|-- G5zLehz4 .txt
|-- iTwTrTkU .txt
|-- vPcaO7jR .csv
|-- 1 Vgi2jbe .log
‘-- 7 NMaq7aa .csv
0 directories , 5 files
"""

import os
import random
import string
import shutil

def mappe_filer_oppgave4(base=".", antall=30):
    lader = os.path.join(base, "Files")
    if os.path.exists(lader):
        shutil.rmtree(lader)
    os.makedirs(lader, exist_ok=True)

    fil_endelser, tegn = [".txt", ".csv", ".log"], string.ascii_letters + string.digits

    for _ in range(antall):
        navn = "".join(random.choice(tegn) for _ in range(random.randint(5, 10)))
        ext = random.choice(fil_endelser)
        fillader = os.path.join(lader, navn + ext)
        with open(fillader, "w", encoding="utf-8") as f:
            pass

    return lader

if __name__ == "__main__":
    print("Filer opprettet i:", mappe_filer_oppgave4(".", 5))

