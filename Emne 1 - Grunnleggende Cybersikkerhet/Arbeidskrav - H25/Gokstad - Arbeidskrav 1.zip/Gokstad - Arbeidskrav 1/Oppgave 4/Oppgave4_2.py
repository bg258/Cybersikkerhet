"""
Oppgave 4.2
Lag en funksjon som leser filene i Files og sorterer dem i undermapper
basert p˚a filtype:

    • Opprett en ny mappe kalt SortedFiles
    • Opprett undermapper kalt txt-files, csv-files, og log-files inne
      i denne mappen kalt SortedFiles.
    • Flytt filene fra Files til riktig undermappe i SortedFiles basert på deres filtype.

SortedFiles
|-- csv
| |-- vPcaO7jR .csv
| ‘-- 7 NMaq7aa .csv
|-- log
| ‘-- 1 Vgi2jbe .log
‘-- txt
|-- G5zLehz4 .txt
‘-- iTwTrTkU .txt
3 directories , 5 files
"""

import os
import shutil

def undermapper(base="."):
    filer_link = os.path.join(base, "Files")
    pos = os.path.join(base, "SortedFiles")

    if os.path.exists(pos):
        shutil.rmtree(pos)
    os.makedirs(os.path.join(pos, "txt-files"), exist_ok=True)
    os.makedirs(os.path.join(pos, "csv-files"), exist_ok=True)
    os.makedirs(os.path.join(pos, "log-files"), exist_ok=True)

    if not os.path.exists(filer_link):
        print("Vi kunne ikke finne mappen med navn'Files'. Du må først kjøre oppgave 4.1 først.")
        return pos

    for fil in os.listdir(filer_link):
        full = os.path.join(filer_link, fil)
        if fil.endswith(".txt"):
            shutil.move(full, os.path.join(pos, "txt-files", fil))
        elif fil.endswith(".csv"):
            shutil.move(full, os.path.join(pos, "csv-files", fil))
        elif fil.endswith(".log"):
            shutil.move(full, os.path.join(pos, "log-files", fil))

    return pos

if __name__ == "__main__":
    print("Filer sortert til:", undermapper("."))
