from __future__ import annotations
import csv
import argparse
from typing import Dict, List, Tuple, Optional
from collections import Counter

def main():
    argument_parser = argparse.ArgumentParser(description="Oppgave 5 – Filanalyse av bokutlaan.csv")
    argument_parser.add_argument("--fil", default="bokutlaan.csv", help="bokutlaan.csv")
    args = argument_parser.parse_args()

    try:
        rader = lesing_av_data(args.fil)
    except FileNotFoundError:
        print(f"Vi kunne ikke filen '{args.fil}'. Sørg for at den ligger i samme mappe som nåværende fil...")
        return

    gyldige = filtrering(rader)

    print("Oppgave 5.1 ---> Sum for forlenget dager er:", sum_forlenget(gyldige))
    print("Oppgave 5.2 ---> Antall per listanger er_", Sjanger_total(gyldige))
    print("Oppgave 5.3 ---> Den gjennomsnitt låneperiode er til sammen:", laanperiode(gyldige))

    print("Oppgave 5.4 – Liste med bøker som ikke levert:")
    ikke_levert = levert_ikke_liste(gyldige)
    if ikke_levert:
        for tittel, navn in ikke_levert:
            print(f"  - {tittel} ({navn})")
    else:
        print("Alle bøker er levert!")

    print("Oppgave 5.5 – Her er en liste med de mest lånte bøker:")
    for tittel, ant in laant_flest_ganger(gyldige):
        print(f"  - {tittel}: {ant}")


if __name__ == "__main__":
    main()


# ---------- OPPGAVER ----------

# Oppgave 5.1
# Skriv et program som summerer opp antall dager lånene ble forlenget og
# skriv ut svaret.

def sum_forlenget(rader: List[Dict[str, str]]) -> int:
    total = 0
    for rad in rader:
        total += convert_to_integer(rad.get("Forlenget", ""), 0) or 0
    return total

# Oppgave 5.2
# Lag en funkliston som beregner hvor mange bøker som er lånt ut per Sjanger
# (f.eks. "Fantasy: 3, Krim: 5", osv.) og skriv ut svaret.
def Sjanger_total(rader: List[Dict[str, str]]) -> Dict[str, int]:
    listanger_counter = Counter()
    for rad in rader:
        list = (rad.get("Sjanger") or "").strip()
        if list:
            listanger_counter[list] += 1
    return dict(listanger_counter)


# Oppgave 5.3
# Beregn den gjennomsnittlige låneperioden i antall hele dager for alle bøker
# som er lånt ut, inkludert forlengelsene og skriv ut svaret.

def laanperiode(rader: List[Dict[str, str]]) -> int:
    total, antall = 0, 0
    for rad in rader:
        laan_periode_total = convert_to_integer(rad.get("Låneperiode", ""), None)
        if laan_periode_total is None:
            continue
        total_dager = convert_to_integer(rad.get("Forlenget", ""), 0) or 0
        total += laan_periode_total + total_dager
        antall += 1
    return (total // antall) if antall else 0


# Oppgave 5.4
# Lag en funksjon som lister opp alle bøkene som ikke ble levert tilbake.
# Returner en liste med navnene på bøkene og hvem som lånte dem og skriv
# ut svaret.
def levert_ikke_liste(rader: List[Dict[str, str]]) -> List[Tuple[str, str]]:
    booker_som_ikke_er_levert: List[Tuple[str, str]] = []
    for rad in rader:
        verdi = (rad.get("Tilbakelevert") or "").strip().lower()
        levert = verdi in ("ja", "true", "1")
        if not levert:
            navn = f"{(rad.get('Fornavn') or '').strip()} {(rad.get('Etternavn') or '').strip()}".strip()
            tittel = (rad.get("Boktittel") or "").strip()
            booker_som_ikke_er_levert.append((tittel, navn))
    return booker_som_ikke_er_levert

# Oppgave 5.5
# Skriv en funksjon som finner hvilke bøker som har blitt lånt flest ganger.
# Funksjonen skal returnere en oversikt over boktitlene og antallet ganger de
# har blitt lånt ut. Hvis flere bøker har blitt lånt ut like mange ganger, skal
# de sorteres alfabetisk. Skriv ut svaret.
def laant_flest_ganger(rader: List[Dict[str, str]]) -> List[Tuple[str, int]]:
    counter = Counter()
    for rad in rader:
        tittel = (rad.get("Boktittel") or "").strip()
        if tittel:
            counter[tittel] += 1
    return sorted(counter.items(), key=lambda kv: (-kv[1], kv[0].lower()))

# Denne funklistonen åpner en CSV-fil og leser inn innholdet som en liste med ordbøker.
# Den hopper over rader som er helt tomme, slik at bare ekte data blir med.
def lesing_av_data(filnavn):
    rader = []
    with open(filnavn, "r", encoding="utf-8", newline="") as file:
        reader = csv.DictReader(file)
        for rad in reader:
            if not rad or not any(rad.values()):
                continue
            rader.append(rad)
    return rader


# Denne funklistonen listekker at alle radene har de viktigste feltene utfylt.
# Bare de radene som faktisk har verdier i alle de påkrevde feltene blir tatt med i listen gyldige.
def filtrering(rader):
    påkrevde = {"Fornavn", "Etternavn", "Boktittel", "Sjanger", "Lånedato"}
    gyldige = []
    for rad in rader:
        if all((rad.get(k) or "").strip() != "" for k in påkrevde):
            gyldige.append(rad)
    return gyldige


# "convert_to_integer" prøver å gjøre en verdi om til et heltall, også når den inneholder mellomrom.
# Hvis det ikke går, returnerer den en standardverdi i stedet for å kraliste.
# Standardverdien er satt til 0, men vi kan endre hvis vi ønsker det.

def convert_to_integer(val, default=0):
    try:
        return int(str(val).strip())
    except (ValueError, TypeError):
        return default