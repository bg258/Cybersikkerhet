# Oppgave 1
# Lag et program som ber brukeren om å skrive inn et positivt heltall (int)
# og finner summen av alle tall fra 1 til dette tallet (inkludert).
# Summen skal beregnes ved hjelp av en for-løkke.

def sum_til_tallet_n(n: int) -> int:
    if n < 0:
        raise ValueError("n må være lik 0 eller større")
    s = 0
    for i in range(1, n + 1):
        s += i
    return s

if __name__ == "__main__":
    try:
        n_str = input("Skriv inn et positivt heltall: ").strip()
        n = int(n_str)
        if n < 0:
            print("Feil: tallet må være 0 eller større.")
        else:
            print(f"Summen fra 1 til {n} er {sum_til_tallet_n(n)}")
    except ValueError:
        print("Feil: du må skrive et heltall (for eksempel 7).")
