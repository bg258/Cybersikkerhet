# Oppgave 1.2
# Skriv et program som ber brukeren skrive inn to setninger. Programmet
# skal deretter sammenligne lengden p˚a de to setningene og skrive ut hvilken
# som er lengst og antall karakterer det er i denne setningen.


def hvilke_setning_er_lengst(s1, s2):
    if len(s1) > len(s2):
        return s1, len(s1)
    elif len(s2) > len(s1):
        return s2, len(s2)
    else:
        return None

if __name__ == "__main__":
    s1 = input("Skriv setning 1: ")
    s2 = input("Skriv setning 2: ")

    resultat = hvilke_setning_er_lengst(s1, s2)
    if resultat is None:
        print(f"Setningene er like lange ({len(s1)} tegn hver).")
    else:
        tekst, lengde = resultat
        print(f"Den lengste setningen er: \"{tekst}\"")
        print(f"Antall tegn: {lengde}")
