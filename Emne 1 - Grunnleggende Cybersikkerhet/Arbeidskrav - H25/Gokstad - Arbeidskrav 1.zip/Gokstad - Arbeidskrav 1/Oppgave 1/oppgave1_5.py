# Oppgave 1.5
# Utvid Oppgave 1.3 slik at brukeren kan angi et intervall [m, n] i stedet for
# 1-10, og programmet skriver ut en pent formatert tabell for tallet i hele
# intervallet.

def formattering(m, n):
    if m > n:
        m, n = n, m
    overskrift = " | ".join(str(x) for x in range(m, n + 1))
    print(f"| {overskrift} |")
    print("|" + "|".join("---" for _ in range(m, n + 1)) + "|")
    for i in range(m, n + 1):
        rad = " | ".join(str(i * j) for j in range(m, n + 1))
        print(f"| {rad} |")

if __name__ == "__main__":
    m = int(input("Skriv inn start på intervallet: "))
    n = int(input("Skriv inn slutt på intervallet: "))
    formattering(m, n)
