# Oppgave 1.3
# Lag et program som ber brukeren skrive inn et tall og genererer multiplikasjonstabellen
# for dette tallet (fra 1 til 10).
    
def multiplikasjonstabell(tall):
    for i in range(1, 11):
        print(f"{tall} * {i} = {tall * i}")

if __name__ == "__main__":
    n = int(input("Skriv inn et tall: "))
    multiplikasjonstabell(n)
