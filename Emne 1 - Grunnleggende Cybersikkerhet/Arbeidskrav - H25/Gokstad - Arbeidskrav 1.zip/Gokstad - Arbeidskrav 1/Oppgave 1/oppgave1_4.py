# Oppgave 1.4
# Lag et program som bytter plass på to elementer i en gitt liste. Programmet
# skal ta utgangspunkt i følgende liste:

fruits = ["eple", "banan", "appelsin", "drue", "kiwi"]

# 1. Be brukeren om å skrive inn to indekser (input) som angir hvilke elementer i 
#    listen som skal bytte plass
# 2. Bytt plass p˚a elementene som ligger p˚a de angitte indeksene
# 3. Skriv ut den oppdaterte listen

# Hvis en eller begge indeksene er ugyldige (ikke i listen), skal programmet gi
# en passende feilmelding

fruits = ["eple", "banan", "appelsin", "drue", "kiwi"]

def plassbytte(liste, i, j):
    if i < 0 or j < 0 or i >= len(liste) or j >= len(liste):
        print("Ugyldig indeks")
        return liste
    liste[i], liste[j] = liste[j], liste[i]
    return liste

if __name__ == "__main__":
    try:
        i = int(input("Skriv første indeks: "))
        j = int(input("Skriv andre indeks: "))
        print(plassbytte(fruits, i, j))
    except ValueError:
        print("Du må skrive inn heltall")
