# Oppgave 2.3
# Ta utgangspunkt i listene fra Oppgave 2.2 og lag en dictionary der tekstverdier
# fra listen med navn blir nøkler og tallverdiene fra listen med alder blir
# verdier. Skriv ut innholdet av denne dictionary på formatet:

"Cecilie er 25 ˚ar"
"Bjørn er 30 ˚ar"

def list_til_dictionary(navn, alder):
    return dict(zip(navn, alder))

if __name__ == "__main__":
    navn = ["Cecilie", "Bjørn", "Tor", "Anna"]
    alder = [25, 30, 24, 25]
    personer = list_til_dictionary(navn, alder)
    for n, a in personer.items():
        print(f"{n} er {a} år")
