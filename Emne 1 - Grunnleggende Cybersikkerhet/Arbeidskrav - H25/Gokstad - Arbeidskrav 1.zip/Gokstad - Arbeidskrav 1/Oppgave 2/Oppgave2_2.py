# Oppgave 2.2
# Ta utgangspunkt i en liste der tekst og tall er plassert parvis med navn og
# alder slik:

["Cecilie", 28, "Bjørn", 30, "Tor", 24, "Anna", 25]

# Skriv et program som splitter denne listen i to separert lister, en liste for
# navn og en liste for alder.

def splytting(miks):
    navn = []
    alder = []
    for i in range(0, len(miks), 2):
        navn.append(miks[i])
        alder.append(miks[i+1])
    return navn, alder

if __name__ == "__main__":
    miks = ["Cecilie", 28, "Bjørn", 30, "Tor", 24, "Anna", 25]
    navn, alder = splytting(miks)
    print("Navn:", navn)
    print("Alder:", alder)
