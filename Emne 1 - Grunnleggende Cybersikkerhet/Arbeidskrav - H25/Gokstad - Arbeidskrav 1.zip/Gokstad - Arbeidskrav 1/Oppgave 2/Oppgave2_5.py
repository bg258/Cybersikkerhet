# Oppgave 2.5
# Ta utgangspunktet i dictionary som er sortert p˚a navn i Oppgave 2.4 og
# lag en ny liste med disse verdiene slik at listen f˚ar samme format som den i
# Oppgave 2.2, men sortert p˚a navn.

["Anna", 25, "Bjørn", 30, "Cecilie", 28, "Tor", 24]

def sortering_basert_navn(d):
    resultat = []
    for navn, alder in sorted(d.items(), key=lambda par: par[0]):
        resultat.append(navn)
        resultat.append(alder)
    return resultat

if __name__ == "__main__":
    personer = {"Cecilie": 28, "Bjørn": 30, "Tor": 24, "Anna": 25}
    liste = sortering_basert_navn(personer)
    print(liste)

