#Oppgave 2.6
# Konverter datasettet fra Oppgave 2.2 til en liste av dictionaries med formatet:

"""
{"navn": "Cecilie", "alder": 28}
"""

def liste_med_dictionaries(d):
    return [{"navn": navn, "alder": alder} for navn, alder in d.items()]

if __name__ == "__main__":
    personer = {"Cecilie": 28, "Bjørn": 30, "Tor": 24, "Anna": 25}
    liste = liste_med_dictionaries(personer)
    print(liste)
