# Oppgave 2.1
# Skriv et program som leser inn en dato i formatet “dd/mm/yyyy” fra
# brukeren. Programmet skal deretter sjekke om datoen er gyldig. Hvis datoen
# er ugyldig, skal programmet skrive en passende feilmelding.

def lese_dato_gyldig(dato):
    try:
        d, m, y = dato.split("/")
        d, m, y = int(d), int(m), int(y)
        import datetime
        datetime.date(y, m, d)
        return True
    except Exception:
        return False

if __name__ == "__main__":
    dato = input("Skriv inn en dato (dd/mm/yyyy): ")
    if lese_dato_gyldig(dato):
        print("Datoen er gyldig")
    else:
        print("Datoen er ugyldig")

