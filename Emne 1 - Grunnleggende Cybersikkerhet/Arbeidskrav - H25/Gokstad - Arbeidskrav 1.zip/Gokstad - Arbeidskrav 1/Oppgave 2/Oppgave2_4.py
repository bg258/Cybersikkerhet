# Oppgave 2.4
# Skriv et program som sorterer denne dictionary etter alder hvor den eldste
# skal være først. Skriv ut resultatet.

def dictionary_is_sorted(d):
    return sorted(d.items(), key=lambda par: par[1], reverse=True)

if __name__ == "__main__":
    personer = {"Cecilie": 25, "Bjørn": 30, "Tor": 24, "Anna": 25}
    sortert = dictionary_is_sorted(personer)
    for navn, alder in sortert:
        print(f"{navn} er {alder} år")
